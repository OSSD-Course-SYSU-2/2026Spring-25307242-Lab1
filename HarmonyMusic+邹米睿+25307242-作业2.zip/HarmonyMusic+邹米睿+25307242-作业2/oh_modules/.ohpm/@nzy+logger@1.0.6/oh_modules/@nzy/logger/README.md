# Logger

[Android logger](https://github.com/orhanobut/logger)

HarmonyOS使用的日志库，具备轻量、美观强大、可扩展的特性。使用API 12，点击可以跳转到源文件
### 打印日常
![输入图片说明](https://img.picgo.net/2024/08/23/image1ac82b59ddecf7c85.webp)
### 打印Error或者BusinessError
![输入图片说明](https://img.picgo.net/2024/09/04/image21591085d168dab57.jpeg)
### 写入文件
因为按行写的一条日志，里面可能有换行符，所以把换行符都替换成‘-----’这个了

![输入图片说明](https://img.picgo.net/2024/09/04/image5982d45ba56b9255.png)
## 快速开始

### 安装

```shell
ohpm install @nzy/logger
```

### 导入

```typescript
import { Logger } from '@nzy/logger';
```

### 打印日志

```typescript
Logger.debug('hello world')
Logger.info(new Person())
Logger.warn(new Person())
Logger.error('这是一个error')
Logger.fatal('这是一个fatal')
Logger.json(new Person())
```

### 全局初始化

如果需要写入文件功能，请尽早初始化

```typescript
// 也可以不用初始化
Logger.init();
// 或者传递过去，如果要是写入文件 jsonWrite = true ，必须传递parentPath，必须传递 FileStrategy
Logger.init({
  domain: 0x0000, // domain
  isEnable: true, // 是否打印，默认是 true，是否打印，不影响写文件
  isShowFile: true, // 是否显示打印日志文件的位置 默认 true
  tag: 'MyTag', // 全局TAG 默认是 Logger
  jsonWrite: true, // 是否写入文件 默认是 true
  debugLevelWrite: true, // debug级别的是否写入文件 默认是 true
  parentPath: parentPath // 写入文件的 parent 路径
},
  new FileStrategy(`${Date.now()}.txt`)// 要写入文件策略模式，自己也可以去实现
)
```

### LogOptions

| 属性         | 默认值    | 	描述                                             |
|:-----------|:-------|:------------------------------------------------|
| domain     | 0x0000 | Hilog的domain                                    |
| isEnable   | true   | 是否打印，不影响写文件                                     |
| isShowFile | true   | 是否显示打印的文件以及行号                                   |
| tag        | Logger | 全局TAG                                           |
| jsonWrite  | true   | 是否写入文件，必须传递`FileStrategy`才能真正写入                 |
| parentPath | 无      | 写入文件的 parent 路径，方便当有多个日志文件的时候，全部捞出来，`如果要写入 必须传` |

### 设置新的FileStrategy

当设置新的FileStrategy的时候，日志会写入新的文件，并且返回旧文件的全路径，可以拿这个旧文件上传到服务器，上传成功请删除旧文件

```ts
let oldFilePath = Logger.setNewFile(new FileStrategy(`${Date.now()}.txt`))
// 可以把这个上传到服务器
if (oldFilePath && fs.accessSync(oldFilePath)) {
  // 存在 上传给服务器
  // 删除此文件
  // fs.unlinkSync(oldFilePath)
  console.log('上传服务器，并且删除此文件')
}
```

### 拿到所有的日志文件

在全局初始化的时候，有个parentPath，当冷启动的时候，可以拿到所有这个文件夹下的所有日志，上传给服务器，并且删除
```ts
let parentPath = getContext(this).getApplicationContext().filesDir
// 当启动起来的时候
// 去拿parentPath下面所有的文件，然后上传上去
// 这里面有可能是多个文件
let files: string[] = fs.listFileSync(parentPath)
```

## 注意点

### 跳转到源文件

由于 DevEco Studio 只能在error和warn的情况下才能跳转源文件，所以需要 DevEco Studio
安装一个插件 [awesome-console](https://plugins.jetbrains.com/plugin/7677-awesome-console),并且在 DevEco Studio 中
Marketplace 搜不到，所以需要从 [awesome-console](https://plugins.jetbrains.com/plugin/7677-awesome-console) 手动安装

### 打印丢失

如果打印过大的Json，在模拟器上有可能丢失，在真机上不会丢失（但是比如循环10000次打印 ，在真机上也会丢失），HiLog和console属于DevEco
Studio 的bug
比如 这样就 在模拟器中就会丢失，在真机就不会丢失，如果index < 10000 ,真机也会丢失

```ts
 for(let index = 0; index<1000;index++){
      console.log(`----${index}-----`)
    }
```

## 贡献代码
使用过程中发现任何问题都可以提 [Issue](https://gitee.com/zhiyangnie/logger/issues)。
给我们，当然，我们也非常欢迎你给我们发 [PR](https://gitee.com/zhiyangnie/logger/pulls) 。



## 开源协议

本项目基于 Apache License 2.0 ，请自由地享受和参与开源。