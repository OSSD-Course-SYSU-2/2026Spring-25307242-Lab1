/**
 * 创建 WebServer服务器
 */
// 引入http 核心模块
const http = require('http')

// 创建服务器对象实例
const server =  http.createServer((request, response) => {
    // 在回调函数中，对请求 request 与响应 response 进行处理
    // TODO :: 处理请求
    
    // 发送 HTTP 头部
    // http 状态值： 200 : ok
    response.writeHead(200, {'Content-Type': 'text/plain'})

    // 发送响应数据 "Hello World"
    response.end('Hello World\n')
})


// 监听端口
server.listen(2597,() => {
    console.log('server is running at http://127.0.0.1:2597')
})


